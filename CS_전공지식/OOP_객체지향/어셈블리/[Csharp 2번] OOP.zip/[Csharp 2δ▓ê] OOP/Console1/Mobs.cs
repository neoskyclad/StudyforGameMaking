﻿public class Mobs
{
    public interface IHitable
    {
        void GetHit(int _damage, String _hitBy);
    }

    public interface IInvincible
    {
        bool SetInvincibleState();
    }

    public interface IDie
    {
        void Die();
    }

    public struct Coords
    {
        public Coords(int x, int y) { this.x = x; this.y = y; }
        public int x {get;set;}
        public int y { get; set; }
    }

    public class Unit : IHitable, IDie
    {
        private int _mHelthPoint;
        public int helthPoint {
            get { return _mHelthPoint; } 
            set { if (value < 0) value = 0; }
        }
        private float _mForwardAngle;
        public float forwardAngle
        {
            get { return _mForwardAngle; }
            set { _mForwardAngle = value % 360.0f; }
        }

        public bool invincibleState;
        
        public Coords position = new Coords(0, 0);

        public Unit() {
            helthPoint = 0;
            forwardAngle = 0.0f;
            invincibleState = false;
        }

        public virtual void GetHit(int _damage, String _hitBy)
        {
            this.helthPoint -= _damage;
            Console.WriteLine($"데미지 :{_damage} 아 잠만 나 맞았어!!");
            if (this.helthPoint < 0) { Die(); }
            return;
        }
        public void Die()
        {
            Console.WriteLine("힝 나 죽었어");
            Console.WriteLine("이펙트 뻥~");
        }
    }
}
