﻿using System;
using static Mobs;

namespace GearHeart
{
    internal class GearHearUnit
    {
        public class OSEL : Unit
        {
            public int ammo { get; set;}
            public OSEL(Coords _pos, int _helth) {

                position = _pos; helthPoint = _helth;
                ammo = 3;
                Console.WriteLine("오셀 생성 : 오셀이 지하 공장에서 안녕이라고 인사");
                Console.WriteLine("총알 3개 있으니 한번 써봐 ㅋㅋ");
            }
            public void Shot() {
                if (ammo != 0)
                {
                    Console.WriteLine("총알 하나 소비함 : 빵야 빵야");
                    ammo--;
                }
                else Console.WriteLine("총알 없음 에휴..");
            }
        }
    }
}
