﻿using System;
using static Mobs;
namespace GearHeart
{
    using static GearHearUnit;
    internal class App
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello From Project GearHeart!");
            OSEL Osel = new OSEL( new Coords(0, 0) ,100);
            do { Osel.Shot(); } while (Osel.ammo != 0);
            Osel.Shot();
            Osel.ammo = 5;
            do { Osel.Shot(); } while (Osel.ammo != 0);
            Osel.GetHit(50, "푸에르");
            Osel.Shot();
            Osel.GetHit(51, "푸에르");
        }
    }
}
