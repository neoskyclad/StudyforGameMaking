﻿using System;
using System.Collections;
using static Mobs;

namespace PROJECT_SoPhIA
{
    using static Equipment.Weapon;
    using static Equipment;
    internal class SophiaUnit
    {
        public struct UnitStatus
        {
            private int _mHp;
            private int _mEnergy;

            public Coords position;
            public int hp { get { return _mHp; } set { _mHp = value < 0 ? 0 : value; } }
            public int energy { get { return _mEnergy; } set { _mEnergy = value < 0 ? 0 : value; } }
            public int defense { get; set; }
            public bool invinsibleStatus { get; set; }
            public UnitStatus()
            {
                position = new Coords(0, 0);
                hp = energy = defense = 0;
                invinsibleStatus = false;
            }
        }

        public class Player : Unit
        {
            public UnitStatus status;
            public ArrayList buffList;
            public Weapon weapon;

            public String? skill_Q;
            public void Q(){return;}

            public String? skill_E;
            public void E() {return;}

            public String? skill_R;
            public void R() { return; }

            public Player()
            {
                status = new UnitStatus();
                status.hp = helthPoint;
                buffList = new ArrayList();
                weapon = new UndefinedWeapon();
            }

            public override void GetHit(int _damage, String _hitBy) {
                status.hp -= _damage;
                Console.WriteLine($"데미지 :{_damage} 아 잠만 나 맞았어!!");
                if (status.hp < 0) { Die(); }
                return;
            }

            public void PrintStatus()
            {
                Console.WriteLine(
                $"hp : {this.status.hp} \n" +
                $"energy : {this.status.energy} \n" +
                $"defense : {this.status.defense} \n" +
                $"invinsible : {this.status.invinsibleStatus} \n" +
                $"position : {this.status.position.x} {this.status.position.y} \n"
                );
            }
        }
    }
}