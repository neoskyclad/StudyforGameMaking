﻿using System;

namespace PROJECT_SoPhIA
{
    internal class Equipment
    {
        public struct Wealth {
            private int _mGear;
            private int _mEnergyCore;
            public int gear { get { return _mGear; } set { _mGear = value < 0 ? 0 : value; } }
            public int energyCore { get { return _mEnergyCore; } set { _mEnergyCore = value < 0 ? 0 : value; } }
        }
        public abstract class Weapon {
            public String weaponName = "undefined_weaponName";
            public String weaponType = "undefined_Type";
            public String weaponModel = "undefined_Model";

            public float damage = -1f;
            public float speed = -1f;
            public int gage = -1;
            public float range = -1f;
            public float coolDown = -1f;

            public abstract void Attack();
            public abstract void WeaponSkill();

            public virtual void PrintWeaponState()
            {
                Console.Write($"weaponName : {this.weaponName}");
                Console.Write($"weaponType : {this.weaponType}");
                Console.WriteLine($"weaponModel : {this.weaponModel}");
                Console.Write($"damage : {this.damage}");
                Console.Write($"speed : {this.speed}");
                Console.Write($"gage : {this.gage}");
                Console.Write($"range : {this.range}");
                Console.WriteLine($"coolDown : {this.coolDown}");

            }
        }
        public class UndefinedWeapon : Weapon {
            public override void Attack() { Console.WriteLine("무기가 없으심.."); }

            public override void WeaponSkill() { Console.WriteLine("무기가 없으심.. 스킬도없음"); }
        }
        public class Sword : Weapon {
            public override void Attack()
            {
                Console.WriteLine("슝");
                Console.WriteLine("슝");
                Console.WriteLine("탁!");
            }
            public override void WeaponSkill() {
                Console.WriteLine("칼 스킬 쓱~~싹");
            }
        }
        public class Gun : Weapon
        {
            public override void Attack()
            {
                Console.WriteLine("푸타타타타탕!");
            }
            public override void WeaponSkill()
            {
                Console.WriteLine("호오.. 잔상입니다만.");
            }
        }
    }
}