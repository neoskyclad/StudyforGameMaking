﻿using System;

namespace PROJECT_SoPhIA
{
    using static SophiaUnit;
    using static Equipment;
    internal class App
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello From Project SoPhiA!");
            Player sophia = new Player();
            sophia.status = new UnitStatus() { hp = 100, energy = -1, defense = 0, invinsibleStatus = false };
            
            sophia.PrintStatus();
            sophia.weapon.PrintWeaponState();
            
            sophia.GetHit(20, "mobs"); sophia.PrintStatus();
            sophia.weapon.Attack();
            sophia.weapon.Attack();
            sophia.GetHit(79, "mobs"); sophia.PrintStatus();
            
            sophia.weapon = new Sword();
            sophia.weapon.PrintWeaponState();

            sophia.weapon.Attack(); sophia.weapon.WeaponSkill();

            sophia.GetHit(1000, "mobs");
        }
    }
}
